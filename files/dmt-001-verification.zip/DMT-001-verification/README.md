# DMT-001 verification bundle

**Paper:** *Regularity-Selected Generic Rank at Least Four in the Piezas Diophantine Sextuple*

This archive contains the machine-readable certificates and exact data supporting the theorem

\[
\operatorname{rank} E_T(\mathbf Q(t))\ge 4,
\qquad
T\in\{ace,acf,bde,bdf,bef,cef\}.
\]

The proof has two exact layers and one certified numerical layer:

1. **Exact symbolic structure.** The Piezas functions form a rational Diophantine sextuple; all 15 pair-square witnesses are explicit rational functions in `Q(t)`. The three regular quadruples `abef`, `adef`, `cdef` and two regular quintuples `abcde`, `abcdf` hold identically. Their graph has special pair `{e,f}` and core path `c-d-a-b`, selecting exactly six triple classes.
2. **Exact rational sections.** Each selected triple has four explicit sections: `P`, `R`, and two extension sections. Their curve identities are algebraic identities once the pair-square witnesses are imposed.
3. **Certified independence at one good specialization.** At `t=12/5`, the four points on each of the six curves have a canonical-height Gram matrix enclosed by the intervals in `certificates/canonical_height_gram_certificates.json`. Outward-rounded interval Cholesky has four strictly positive pivots in every case, so the exact Gram matrices are positive definite and the specialized points are independent. Any integer relation among the generic sections would specialize to the same relation at this good parameter, so the generic sections are independent over `Q(t)`.

## Quick verification

Requires Python 3.10+ and SymPy.

```bash
python -m pip install -r requirements.txt
python scripts/verify_all.py
```

The included reference run is `verification_report.txt`; it reports **27/27 checks passed**.

## Contents

- `certificates/piezas_rank4_certificate.json` — Piezas-only theorem certificate extracted from the raw SIX4 output.
- `certificates/canonical_height_gram_certificates.json` — all six 4x4 canonical-height Gram interval matrices and certified Cholesky pivots.
- `certificates/cholesky_pivots.csv` — compact human-readable pivot table.
- `exact/pair_witnesses_Qt.json` — all 15 rational square witnesses `rho_ij(t)`.
- `exact/regularity_identities.json` — the five regularity identities and the six-class selection data.
- `exact/specialization_t_12_5.json` — exact sextuple values, pair roots, six specialized curves, and all 24 specialized point coordinates.
- `exact/specialization_points.csv` — the same specialized points in spreadsheet-friendly form.
- `scripts/verify_all.py` — standalone audit of the exact identities, specialization data, and interval-Cholesky certificates.
- `docs/PROOF_MAP.md` — maps each theorem step to the corresponding data/certificate.
- `docs/HEIGHT_CERTIFICATION_METHOD.md` — describes how the canonical-height intervals in the certificate were generated.
- `source/original_d35six4_artifact.json` — preserved raw machine output from which the Piezas-only certificate was extracted. It also contains an unrelated DKMS control; that material is **not used** in the DMT-001 theorem.
- `MANIFEST.sha256` — SHA-256 checksums for every payload file in the bundle.

## Claim boundary

The bundle proves **generic rank at least 4** for the six named families. It does not prove exact generic rank 4, any generic upper bound, or rank below 4 for the remaining fourteen triple classes.
