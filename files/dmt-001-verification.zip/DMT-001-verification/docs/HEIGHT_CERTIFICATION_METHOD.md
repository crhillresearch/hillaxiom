# Canonical-height certification method

The supplied Gram enclosures were generated from exact elliptic-curve arithmetic and a uniform duplication-tail bound.

For a rational point `P` and duplication depth `n`, the implementation uses the exact projective `x`-coordinate of `2^n P` and forms

\[
  m_n(P)=\frac{h_x(2^nP)}{2\,4^n}.
\]

A curve-only certified constant `log_C` gives the tail radius

\[
  \varepsilon_n=\frac{\log C}{6\,4^n},
\]

so the canonical height is enclosed by

\[
  \widehat h(P)\in
  [\max(0,m_n(P)-\varepsilon_n),\;m_n(P)+\varepsilon_n].
\]

Pairings are then enclosed by polarization,

\[
  \langle P,Q\rangle
  =\frac{\widehat h(P+Q)-\widehat h(P)-\widehat h(Q)}{2},
\]

using outward-rounded interval arithmetic. This produces a symmetric interval enclosure of the full canonical-height Gram matrix.

For DMT-001, all six four-point frames certify already at depth `n=6`. The proof method recorded in the artifact is **fixed-order interval Cholesky**. At each Cholesky step the diagonal Schur complement is evaluated with outward rounding. A strictly positive lower endpoint for every pivot implies that every real symmetric matrix inside the Gram enclosure is positive definite. Hence the exact canonical-height Gram matrix is positive definite, and the four specialized points are independent modulo torsion. Since a nonzero torsion relation would have canonical height zero, positive definiteness gives the required independence.

The complete 4x4 interval matrices and all pivot intervals are in `certificates/canonical_height_gram_certificates.json`. The standalone verifier independently reruns the interval-Cholesky part from those matrices.

The bundle does not replace the exact duplication-tail derivation with floating-point evidence: the floating-point intervals are the outward-rounded output of that certified exact-height procedure, and the raw generator artifact is preserved in `source/original_d35six4_artifact.json`.
