# Proof map

This file records exactly where each part of the DMT-001 theorem is verified.

| Proof step | Mathematical content | Bundle evidence |
|---|---|---|
| 1 | Piezas sextuple is Diophantine over `Q(t)` | `exact/pair_witnesses_Qt.json`; checked by `scripts/verify_all.py` |
| 2 | `abef`, `adef`, `cdef` are regular quadruples | `exact/regularity_identities.json`; exact fraction-field check in verifier |
| 3 | `abcde`, `abcdf` are regular quintuples | same |
| 4 | Regularity data yields special pair `{e,f}` and path `c-d-a-b` | same |
| 5 | Selection rule gives exactly `ace, acf, bde, bdf, bef, cef` | same; verifier checks the set exactly |
| 6 | Four rational sections exist on each selected generic curve | pair witnesses plus universal section identities checked by verifier |
| 7 | Generic curves are not identically singular | verifier checks the nonzero smoothness witness for each class |
| 8 | All four sections specialize correctly at `t=12/5` | `exact/specialization_t_12_5.json`; verifier checks exact rational coordinates |
| 9 | Specialized four-point frames are independent | `certificates/canonical_height_gram_certificates.json`; interval Cholesky rechecked by verifier |
| 10 | Generic independence follows | relation persistence under good specialization |

## Relation-persistence step

Suppose generic sections `Q_1,...,Q_4` satisfied a nonzero integer relation

`n_1 Q_1 + ... + n_4 Q_4 = O` in `E(Q(t))`.

At the good specialization `t=12/5`, all curve and section formulas are defined and the same group-law identity specializes to

`n_1 Q_1(12/5) + ... + n_4 Q_4(12/5) = O`.

The canonical-height Gram certificate proves the four specialized points are independent, so all `n_i=0`, contradiction. No theorem asserting injectivity of the entire specialization map is required.

## Claim boundary

Only the forward lower-bound theorem is certified. No exact-rank or upper-bound statement is encoded in this bundle.
