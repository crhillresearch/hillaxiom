#!/usr/bin/env python3
"""Standalone verification audit for DMT-001.

Checks:
  1. the 15 exact Piezas pair-square witnesses in Q(t);
  2. the five exact regularity identities and the resulting six-class rule;
  3. the universal section identities used for P, R, and extension points;
  4. exact specialization data at t=12/5 for all six selected families;
  5. positive definiteness of all six supplied canonical-height Gram enclosures
     by outward-rounded fixed-order interval Cholesky;
  6. the theorem's explicit claim boundaries.

Requires Python 3.10+ and SymPy.
"""
from __future__ import annotations
import itertools, json, math, sys
from fractions import Fraction
from pathlib import Path
import sympy as sp
from sympy import ZZ
from sympy.polys.rings import ring

ROOT = Path(__file__).resolve().parent.parent
CERT = ROOT / "certificates" / "piezas_rank4_certificate.json"
HEIGHT = ROOT / "certificates" / "canonical_height_gram_certificates.json"
EXACT = ROOT / "exact" / "specialization_t_12_5.json"
PAIR = ROOT / "exact" / "pair_witnesses_Qt.json"

SPECIALIZATION_T = Fraction(12, 5)
GENERIC_CLASSES = {
    "ace": ("d", "f"), "acf": ("d", "e"),
    "bde": ("c", "f"), "bdf": ("c", "e"),
    "bef": ("c", "d"), "cef": ("a", "b"),
}


def family_sympy():
    t=sp.symbols('t'); t2=t*t
    v={
      'a':((t2-2*t-1)*(t2+2*t+3)*(3*t2-2*t+1))/(4*t*(t2-1)*(t2+2*t-1)),
      'b':(4*t*(t2-1)*(t2-2*t-1))/((t2+2*t-1)**3),
      'c':(4*t*(t2-1)*(t2+2*t-1))/((t2-2*t-1)**3),
      'd':((t2+2*t-1)*(t2-2*t+3)*(3*t2+2*t+1))/(4*t*(t2-1)*(t2-2*t-1)),
      'e':(-t*(t2+4*t+1)*(t2-4*t+1))/((t-1)*(t+1)*(t2+2*t-1)*(t2-2*t-1)),
      'f':((t-1)*(t+1)*(3*t2-1)*(t2-3))/(4*t*(t2+2*t-1)*(t2-2*t-1)),
    }
    return t,{k:sp.cancel(x) for k,x in v.items()}


def family_fraction_field():
    R,t0=ring('t',ZZ); K=R.to_field(); t=K(t0); t2=t*t
    vals=(
      ((t2-2*t-1)*(t2+2*t+3)*(3*t2-2*t+1))/(4*t*(t2-1)*(t2+2*t-1)),
      (4*t*(t2-1)*(t2-2*t-1))/((t2+2*t-1)**3),
      (4*t*(t2-1)*(t2+2*t-1))/((t2-2*t-1)**3),
      ((t2+2*t-1)*(t2-2*t+3)*(3*t2+2*t+1))/(4*t*(t2-1)*(t2-2*t-1)),
      (-t*(t2+4*t+1)*(t2-4*t+1))/((t-1)*(t+1)*(t2+2*t-1)*(t2-2*t-1)),
      ((t-1)*(t+1)*(3*t2-1)*(t2-3))/(4*t*(t2+2*t-1)*(t2-2*t-1)),
    )
    return dict(zip('abcdef',vals))


def load_roots(t):
    raw=json.loads(PAIR.read_text())['witnesses']
    return {k:sp.sympify(expr,locals={'t':t}) for k,expr in raw.items()}

def rt(R,x,y): return R[''.join(sorted((x,y)))]


def exact_regularity_and_selection():
    v=family_fraction_field()
    def reg4(a,b,c,d): return (a-b-c+d)**2-4*(a*d+1)*(b*c+1)
    def reg5(a,b,c,d,e): return (a*b*c*d*e+2*a*b*c+a+b+c-d-e)**2-4*(a*b+1)*(a*c+1)*(b*c+1)*(d*e+1)
    quads=['abef','adef','cdef']; quints=['abcde','abcdf']
    ok4=all(reg4(*(v[x] for x in s))==0 for s in quads)
    ok5=all(reg5(*(v[x] for x in s))==0 for s in quints)
    special=set('ef'); edges=[set(s)-special for s in quads]; core=set('abcd')
    deg={x:sum(x in e for e in edges) for x in core}; endpoints={x for x,d in deg.items() if d==1}
    def dist(u,w):
        seen={u}; front={u}
        for n in range(4):
            if w in front:return n
            nxt={y for x in front for e in edges if x in e for y in e if y!=x}; front=nxt-seen; seen|=front
    d2={frozenset((u,w)) for u,w in itertools.combinations(sorted(core),2) if dist(u,w)==2}
    selected={''.join(sorted(special|{x})) for x in endpoints}
    selected|={''.join(sorted(set(p)|{s})) for p in d2 for s in special}
    return ok4,ok5,selected


def universal_section_identities():
    # R section: write ab=r^2-1, ac=s^2-1, bc=u^2-1.
    r,s,u=sp.symbols('r s u')
    x=r*s+r*u+s*u+1; y=(r+s)*(r+u)*(s+u)
    R_ok=sp.expand(y*y-(x+r*r-1)*(x+s*s-1)*(x+u*u-1))==0
    # Extension section identity after factoring abc from each curve factor.
    A,B,C,ra,rb,rc=sp.symbols('A B C ra rb rc')
    # ra^2=A+1, rb^2=B+1, rc^2=C+1 where A=aq, B=bq, C=cq.
    ext_res=sp.expand((ra*rb*rc)**2-(A+1)*(B+1)*(C+1))
    ext_res=ext_res.subs({ra**2:A+1,rb**2:B+1,rc**2:C+1})
    ext_ok=sp.expand(ext_res)==0
    return R_ok,ext_ok


def section_points(cls,exts,t,v,R):
    x,y,z=cls; a,b,c=v[x],v[y],v[z]
    r,s,u=rt(R,x,y),rt(R,x,z),rt(R,y,z)
    pts={'P':(sp.Integer(0),sp.cancel(a*b*c)),
         'R':(sp.cancel(r*s+r*u+s*u+1),sp.cancel((r+s)*(r+u)*(s+u)))}
    for qn in exts:
        q=v[qn]; rr,ss,uu=rt(R,x,qn),rt(R,y,qn),rt(R,z,qn)
        pts[f'E_{qn}']=(sp.cancel(a*b*c*q),sp.cancel(a*b*c*rr*ss*uu))
    return (a,b,c),pts

# Outward-rounded interval arithmetic: independent recheck of supplied Gram certificates.
def down(x): return math.nextafter(float(x),-math.inf)
def up(x): return math.nextafter(float(x),math.inf)
def iadd(a,b): return (down(a[0]+b[0]),up(a[1]+b[1]))
def isub(a,b): return (down(a[0]-b[1]),up(a[1]-b[0]))
def imul(a,b):
    z=(a[0]*b[0],a[0]*b[1],a[1]*b[0],a[1]*b[1]); return (down(min(z)),up(max(z)))
def isquare(a):
    lo,hi=a
    if lo>=0:return (down(lo*lo),up(hi*hi))
    if hi<=0:return (down(hi*hi),up(lo*lo))
    return (0.0,up(max(lo*lo,hi*hi)))
def idiv(a,b):
    assert not (b[0]<=0<=b[1]); z=(a[0]/b[0],a[0]/b[1],a[1]/b[0],a[1]/b[1]); return (down(min(z)),up(max(z)))
def isqrt(a):
    assert a[0]>=0; return (0.0 if a[0]==0 else down(math.sqrt(a[0])),up(math.sqrt(a[1])))
def interval_cholesky(G):
    k=len(G); L=[[None]*k for _ in range(k)]; piv=[]
    for i in range(k):
        s=(0.0,0.0)
        for m in range(i): s=iadd(s,isquare(L[i][m]))
        d=isub(tuple(G[i][i]),s); piv.append(d)
        if d[0]<=0:return False,piv
        L[i][i]=isqrt(d)
        for j in range(i+1,k):
            s=(0.0,0.0)
            for m in range(i): s=iadd(s,imul(L[j][m],L[i][m]))
            L[j][i]=idiv(isub(tuple(G[j][i]),s),L[i][i])
    return True,piv


def qstr(x):
    x=sp.Rational(x); return str(int(x.p)) if x.q==1 else f'{int(x.p)}/{int(x.q)}'


def main():
    checks=[]
    t,v=family_sympy(); R=load_roots(t)
    checks.append(('15 pair-square identities in Q(t)',all(sp.cancel(R[k]**2-(v[k[0]]*v[k[1]]+1))==0 for k in R)))
    ok4,ok5,selected=exact_regularity_and_selection()
    checks += [('3 regular quadruple identities in Q(t)',ok4),('2 regular quintuple identities in Q(t)',ok5),('regularity graph selects exactly six classes',selected==set(GENERIC_CLASSES))]
    R_ok,E_ok=universal_section_identities(); checks += [('universal R-section identity',R_ok),('universal extension-section identity',E_ok)]

    exact=json.loads(EXACT.read_text()); q=sp.Rational(12,5)
    for cls,exts in GENERIC_CLASSES.items():
        tri,pts=section_points(cls,exts,t,v,R)
        smooth=sp.cancel(tri[0]*tri[1]*tri[2]*(tri[0]-tri[1])*(tri[0]-tri[2])*(tri[1]-tri[2]))!=0
        checks.append((f'{cls}: generic cubic nonsingular',smooth))
        got={name:[qstr(sp.cancel(P[0].subs(t,q))),qstr(sp.cancel(P[1].subs(t,q)))] for name,P in pts.items()}
        checks.append((f'{cls}: exact t=12/5 points match',got==exact['classes'][cls]['points']))

    h=json.loads(HEIGHT.read_text())
    for cls,row in h['classes'].items():
        ok,piv=interval_cholesky(row['gram_intervals'])
        checks.append((f'{cls}: canonical-height Gram enclosure positive definite',ok and len(piv)==4 and all(p[0]>0 for p in piv)))

    c=json.loads(CERT.read_text()); th=c['piezas_generic_theorem']; b=c['claim_boundaries']
    checks.append(('certificate names the six selected classes',set(th['distinguished_classes'])==set(GENERIC_CLASSES)))
    checks.append(('certificate gives rank lower bound 4 for all six',th['all_six_generic_rank_at_least_4'] and all(r['generic_rank_lower_bound']==4 for r in th['rows'])))
    checks.append(('claim boundaries preserved',not b['generic_exact_rank_claim_made'] and not b['generic_rank_upper_bound_claim_made'] and not b['fourteen_classes_generic_rank3_claim_made']))

    failed=[n for n,o in checks if not o]
    for n,o in checks: print(('[PASS] ' if o else '[FAIL] ')+n)
    print(f'\n{len(checks)-len(failed)}/{len(checks)} checks passed.')
    if failed:
        print('FAILED:',*failed,sep='\n - '); return 1
    print('\nCONCLUSION: ace, acf, bde, bdf, bef, cef each carry four certified independent rational sections over Q(t); therefore each induced family has generic Mordell-Weil rank at least 4.')
    return 0

if __name__=='__main__': sys.exit(main())
